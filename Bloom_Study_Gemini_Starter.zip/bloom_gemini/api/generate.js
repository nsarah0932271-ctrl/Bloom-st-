import { GoogleGenAI } from "@google/genai";

const MAX_BODY_BYTES = 50_000;
const MAX_QUESTIONS = 50;

function send(res, status, payload) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.send(JSON.stringify(payload));
}

function extractJson(text) {
  const cleaned = String(text || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1));
  throw new Error("Gemini n'a pas renvoyé un JSON valide.");
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return send(res, 405, { error: "Méthode non autorisée. Utilise POST." });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return send(res, 500, { error: "La variable GEMINI_API_KEY n'est pas configurée dans l'hébergement." });

  let raw = "";
  if (typeof req.body === "string") raw = req.body;
  else if (req.body && typeof req.body === "object") raw = JSON.stringify(req.body);
  if (raw.length > MAX_BODY_BYTES) return send(res, 413, { error: "Demande trop volumineuse." });

  let body;
  try { body = typeof req.body === "object" && req.body ? req.body : JSON.parse(raw || "{}"); }
  catch { return send(res, 400, { error: "Corps de requête JSON invalide." }); }

  const test = body.test && typeof body.test === "object" ? body.test : {};
  const requestedCount = Number(test.count ?? 10);
  const count = Math.max(1, Math.min(MAX_QUESTIONS, Number.isFinite(requestedCount) ? requestedCount : 10));
  const subject = String(test.subject || "Matière non précisée").slice(0, 120);
  const lesson = String(test.lesson || "Notions principales").slice(0, 1500);
  const level = String(test.level || "ECG 1").slice(0, 30);
  const difficulty = String(test.difficulty || "Moyen").slice(0, 40);
  const notes = String(test.notes || "").slice(0, 1500);
  const multiple = Boolean(test.multi);

  const prompt = `Tu es un professeur rigoureux de classe préparatoire ECG en français. Génère exactement ${count} questions de QCM.
Matière : ${subject}. Niveau : ${level}. Leçon(s) : ${lesson}. Difficulté : ${difficulty}. Plusieurs bonnes réponses possibles : ${multiple ? "oui" : "non"}.
Consignes supplémentaires : ${notes || "Aucune"}.
Utilise tes connaissances et, lorsque cela apporte une vraie valeur, la recherche Google pour vérifier les faits, les définitions et les références. Ne fabrique jamais de sources ni de faits précis. Les questions doivent être pertinentes pour le programme ECG et comporter des distracteurs plausibles.
Réponds exclusivement avec un objet JSON valide, sans markdown, exactement de cette forme : {"questions":[{"question":"Énoncé","choices":["A. ...","B. ...","C. ...","D. ..."],"correct":[0],"explanation":"Correction pédagogique détaillée en français","lesson":"Notion concernée"}]}
Dans correct, utilise les indices des choix à partir de 0. Chaque question doit avoir 4 choix. Si plusieurs bonnes réponses sont désactivées, il doit y avoir exactement une réponse correcte. Les explications doivent justifier la bonne réponse et signaler le piège éventuel. N'inclus aucune question dont la correction est incertaine.`;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.35,
        maxOutputTokens: Math.min(16000, 800 + count * 350)
      }
    });

    const text = response.text || "";
    const parsed = extractJson(text);
    if (!Array.isArray(parsed.questions) || parsed.questions.length === 0) {
      throw new Error("La réponse ne contient pas de questions.");
    }
    const questions = parsed.questions.slice(0, count).map((q) => ({
      question: String(q.question || "Question non disponible"),
      choices: Array.isArray(q.choices) ? q.choices.slice(0, 4).map(String) : [],
      correct: Array.isArray(q.correct) ? q.correct.map(Number).filter(n => Number.isInteger(n) && n >= 0 && n < 4) : [],
      explanation: String(q.explanation || "Correction non disponible."),
      lesson: String(q.lesson || lesson)
    })).filter(q => q.choices.length === 4 && q.correct.length > 0);

    if (!questions.length) throw new Error("Les questions reçues ne sont pas dans le format attendu.");
    return send(res, 200, { questions, model, webSearchEnabled: true });
  } catch (error) {
    console.error("Bloom Study Gemini error:", error?.message || error);
    const message = String(error?.message || "Erreur inconnue");
    if (/quota|rate.?limit|429/i.test(message)) {
      return send(res, 429, { error: "Limite d'utilisation Gemini atteinte. Réessaie plus tard ou vérifie les quotas dans AI Studio." });
    }
    if (/api.?key|unauthorized|permission|403|401/i.test(message)) {
      return send(res, 502, { error: "Gemini a refusé la clé API. Vérifie la variable GEMINI_API_KEY et les accès de la clé dans Google AI Studio." });
    }
    return send(res, 502, { error: "La génération Gemini a échoué. Vérifie le déploiement, les quotas et le modèle configuré." });
  }
}
