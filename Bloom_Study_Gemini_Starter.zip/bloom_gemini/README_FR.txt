BLOOM STUDY + GEMINI — INSTALLATION ANDROID
===========================================

CE QUI EST INCLUS
- index.html : Bloom Study avec son design existant.
- api/generate.js : fonction serveur qui appelle Gemini sans exposer la clé dans le navigateur.
- package.json : dépendances du serveur.
- vercel.json : configuration du déploiement.
- .env.example : exemple de noms de variables (aucune vraie clé incluse).

IMPORTANT
La clé API n'est pas incluse. Ne l'envoie jamais dans un chat, ne l'ajoute pas à index.html, ni à un dépôt GitHub public.
La génération via Gemini nécessite une clé autorisée et un quota actif. La recherche Google de Gemini peut avoir des conditions et limites différentes de la génération de texte. Vérifie le tableau de bord AI Studio.

ÉTAPES DE DÉPLOIEMENT AVEC UN TÉLÉPHONE ANDROID
1. Télécharge et décompresse Bloom_Study_Gemini_Starter.zip.
2. Ouvre https://github.com/ dans Chrome et connecte-toi.
3. Crée un nouveau dépôt. Pour éviter d'exposer des secrets, ne téléverse jamais de fichier contenant la vraie clé. Tu peux choisir un dépôt privé.
4. Téléverse le contenu du dossier (index.html, api/generate.js, package.json, vercel.json, .gitignore, .env.example). Ne téléverse pas de fichier .env réel.
5. Ouvre https://vercel.com/ et connecte-toi avec GitHub.
6. Choisis Add New / Project, puis importe le dépôt Bloom Study.
7. Lance le déploiement. Vercel détecte la fonction située dans api/generate.js.
8. Dans les paramètres du projet Vercel, ouvre Environment Variables et ajoute :
   Name: GEMINI_API_KEY
   Value: colle ta clé API Gemini dans ce champ sécurisé
   Environments: Production (et Preview si tu veux tester les prévisualisations)
   Enregistre.
9. Ajoute aussi GEMINI_MODEL = gemini-2.5-flash si tu veux préciser le modèle. Cette variable est facultative.
10. Après avoir ajouté/modifié une variable, redéploie le projet (Redeploy).
11. Ouvre l'URL de production Vercel. Connecte-toi dans Bloom Study, puis crée un QCM. L'interface appelle /api/generate automatiquement.

DÉPANNAGE
- Si le site s'ouvre mais les QCM passent en mode démo : ouvre les journaux (Logs) du déploiement Vercel et vérifie que GEMINI_API_KEY existe dans le bon environnement, puis redéploie.
- Erreur 429 : quota ou limite de fréquence atteinte. Attends, réduis les demandes et vérifie les quotas dans AI Studio.
- Erreur 401/403 : vérifie la clé, son type, les autorisations et l'activation de l'API Gemini.
- Erreur de modèle : change GEMINI_MODEL pour un modèle Gemini disponible dans ton compte et compatible avec Google Search grounding.
- Le fichier ouvert directement depuis le téléphone ne peut pas appeler la fonction serveur tant que le site n'est pas déployé. Il faut utiliser l'URL Vercel.

PROTECTION DE LA CLÉ
- Ne mets pas la clé dans index.html ou dans un script exécuté par le navigateur.
- Ne la colle pas dans GitHub, un screenshot ou une conversation.
- Si tu l'as déjà publiée, révoque-la et crée-en une nouvelle.
- Surveille l'utilisation et les quotas dans Google AI Studio.
- Cette version est un starter : avant de partager largement le site, ajoute une protection anti-abus (limites de requêtes par utilisateur/IP, authentification réelle si nécessaire et validation renforcée). Le profil local du prototype n'est pas une vraie authentification serveur.

RESSOURCES OFFICIELLES
Gemini API keys: https://ai.google.dev/gemini-api/docs/api-key
Gemini API getting started: https://ai.google.dev/gemini-api/docs/get-started
Gemini API pricing: https://ai.google.dev/gemini-api/docs/pricing
Vercel environment variables: https://vercel.com/docs/environment-variables
Vercel Hobby: https://vercel.com/docs/plans/hobby
